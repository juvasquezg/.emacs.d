 Show visual bell at right in the echo area.

 Global minor mode `echo-bell-mode' replaces the audible bell
 with a visual indication in the echo area.

 Options:
 * `echo-bell-string' is the text to show.
 * `echo-bell-delay' is the number of seconds to show it.
 * `echo-bell-background' is the background color to use.

Initial code was from http://www.emacswiki.org/emacs/MilesBader.
