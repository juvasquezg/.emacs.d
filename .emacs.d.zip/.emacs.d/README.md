# Emacs text Editor config

Este repositorio consolida la configuraci�n del editor emacs
para ser usado en direferentes tareas.